public class Compiler {
public Compiler() {
}
public void compile(String fileName) {
	System.out.println("Estoy compilando: " + fileName);
}
}
