public class Runtime {

public Runtime() {
	
}
public void run(String fileName) {
	System.out.println("Estoy ejecutando: " + fileName);
	  }
}
