public class JavaDoc {
public JavaDoc() {
	
}
public void generateDocs(String fileName) {
	System.out.println("Estoy documentando: " + fileName);
	  }
}
