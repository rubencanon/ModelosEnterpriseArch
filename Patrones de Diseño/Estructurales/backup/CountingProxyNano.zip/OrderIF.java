import java.util.*;

public interface OrderIF {
  public Vector getAllOrders();
}
