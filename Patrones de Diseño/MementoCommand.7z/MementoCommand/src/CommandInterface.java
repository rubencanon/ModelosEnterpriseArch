
public interface CommandInterface {
	public boolean execute();
}
