public interface CommandInterface {
  public void execute();
}
