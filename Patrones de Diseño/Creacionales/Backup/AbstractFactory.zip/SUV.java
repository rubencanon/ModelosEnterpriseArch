public interface SUV {
  public String getSUVName();
  public String getSUVFeatures();

} // End of class


