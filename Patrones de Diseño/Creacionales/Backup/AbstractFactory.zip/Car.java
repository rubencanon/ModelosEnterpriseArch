public interface Car {
  public String getCarName();
  public String getCarFeatures();

} // End of class


